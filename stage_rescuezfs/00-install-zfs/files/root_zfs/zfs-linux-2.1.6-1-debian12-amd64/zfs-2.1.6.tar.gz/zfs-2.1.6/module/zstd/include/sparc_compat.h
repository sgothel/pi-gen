#if defined(__sparc)
uint64_t __bswapdi2(uint64_t in);
uint32_t __bswapsi2(uint32_t in);
#endif
